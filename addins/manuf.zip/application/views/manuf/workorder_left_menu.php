<h2>Function</h2>
<ul>
<li><?php echo anchor('manuf/workorder/add','New Workorder');?></li>
<li><?php echo anchor('manuf/workorder/browse','List Workorder');?></li>
</ul>
<h2>Search</h2>
Wo Number</br><input type="text" id='search_wo_number' name="search_wo_number"/></br>
Customer</br><input type="text" id='search_cust_number' name="search_cust_number"/></br>
<input type="button" value='Search' id='search' name='search'/>

