<div style="margin:10px 0;"></div>
	<ul class="easyui-tree">
		<li>
			<span>Accounting Modules</span>
			<ul>
				<li>
					<span>Operation</span>
					<ul>
			<li><?=anchor('payroll/salary','Slip Gaji','class="info_link"');?></li>
			<li><?=anchor('payroll/salary/generate','Generate Slip Gaji','class="info_link"');?></li>
			<li><?=anchor('payroll/pph21','Proses PPH 21','class="info_link"');?></li>
			<li><?=anchor('payroll/absensi','Absensi','class="info_link"');?></li>
			<li><?=anchor('payroll/absensi/detail','Absensi Data','class="info_link"');?></li>
			<li><?=anchor('payroll/overtime','Overtime','class="info_link"');?></li>
			<li><?=anchor('payroll/cuti','Cuti','class="info_link"');?></li>
			<li><?=anchor('payroll/pinjaman','Pinjaman','class="info_link"');?></li>
			<li><?=anchor('payroll/pengobatan','Pengobatan','class="info_link"');?></li>
					</ul>
				</li>
				<li   data-options="state:'closed'">
					<span>Report</span>
					<ul>
			<li><?=anchor('payroll/rpt/emp_list','Daftar Karyawan','class="info_link"')?></li>
			<li><?=anchor('payroll/rpt/slip_list','Daftar Slip Gaji','class="info_link"')?></li>
			<li><?=anchor('payroll/rpt/slip_print','Cetak Slip Gaji Massal','class="info_link"')?></li>
			<li><?=anchor('payroll/rpt/slip_bank','Rangkuman Gaji per Bank','class="info_link"')?></li>
			<li><?=anchor('payroll/rpt/absensi','Daftar Absensi','class="info_link"')?></li>
			<li><?=anchor('payroll/rpt/overtime','Daftar Overtime','class="info_link"')?></li>
					</ul>
				</li>
				<li  data-options="state:'closed'">
					<span>Master</span>
					<ul>
			<li><?=anchor('payroll/employee','Pegawai','class="info_link"')?></li>
			<li><?=anchor('payroll/employee/group','Level Group','class="info_link"')?></li>
			<li><?=anchor('payroll/ptkp','Status Kawin (PTKP)','class="info_link"')?></li>
			<li><?=anchor('payroll/employee/jenis','Jenis','class="info_link"')?></li>
			<li><?=anchor('payroll/pelamar','Calon Pegawai','class="info_link"')?></li>
			<li><?=anchor('payroll/income','Jenis Pendapatan','class="info_link"')?></li>
			<li><?=anchor('payroll/deduct','Jenis Potongan','class="info_link"')?></li>
			<li><?=anchor('payroll/level','Level Jabatan (Posisi)','class="info_link"')?></li>
			<li><?=anchor('payroll/holiday','Hari Libur','class="info_link"')?></li>
			<li><?=anchor('payroll/periode','Periode Penggajian','class="info_link"')?></li>
					</ul>
				</li>
			</ul>
		</li>
	</ul>
