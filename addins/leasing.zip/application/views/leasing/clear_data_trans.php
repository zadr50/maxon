<legend>CLEAR DATA TRANSAKSI</legend>
<h1>***WARNING***</h1>
<p>Proses ini akan menghapus seluruh data transaksi leasing,</p>
