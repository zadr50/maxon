<div style="margin:10px 0;"></div>
	<ul class="easyui-tree">
		<li>
			<span>Leasing Modules</span>
			<ul>
				<li>
					<span>Operation</span>
					<ul>
					</ul>
				</li>
				<li   data-options="state:'closed'">
					<span>Report</span>
					<ul>
					</ul>
				</li>
				<li  data-options="state:'closed'">
					<span>Master</span>
					<ul>
					</ul>
				</li>
			</ul>
		</li>
	</ul>
