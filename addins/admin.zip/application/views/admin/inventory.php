<form  id="frmSales" method='post' >
	<table>
		<tr>
			<td colspan="2"><h2>SETTING INVENTORY</h2></td>
		</tr>

	</table>
	
	<input type='submit' name='cmdSave'>
</form>

