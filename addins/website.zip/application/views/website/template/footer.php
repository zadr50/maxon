    <!--footer start-->
    <footer class="footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-4 col-md-4 address wow fadeInUp" data-wow-duration="2s" data-wow-delay=".1s">
            <h1>
              Contact Info
            </h1>
            <address>
              <br/><i class="fa fa-home pr-10"></i>Address: Desa Sawah Kulon
              <br/><i class="fa fa-globe pr-10"></i>Purwakarta, Jawa Barat - Indonesia 
              <br/><i class="fa fa-envelope pr-10"></i>Email :   <a href="javascript:;">zadr50@gmail.com</a>
              <br/><i class="fa fa-mobile pr-10"></i>Phone : 082112829192
           </address>
          </div>
          
          <div class="col-lg-3 col-sm-3 col-md-3">
            <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
              <h1>
                Our Company
              </h1>
              <ul class="page-footer-list">
                <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="<?=base_url()?>index.php/about">About Us</a>
                </li>
                <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="<?=base_url()?>index.php/faq">Support</a>
                </li>
                <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="#">Service</a>
                </li>
                <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="#">Privacy Policy</a>
                </li>
                <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="#">We are Hiring</a>
                </li>
                <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="#">Term & condition</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-sm-4 col-md-4">
            <div class="text-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".7s">

            </div>
           
            <div class="text-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".7s">

            </div>
          </div>
		  
        </div>
      </div>
    </footer>
    <!-- footer end -->
    <!--small footer start -->
    <footer class="footer-small">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-sm-7 col-md-7 pull-right">
                    <ul class="social-link-footer list-unstyled">
                        <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".1s"><a href="https://www.facebook.com/talagasoft"><i class="fa fa-facebook"></i></a></li>
                        <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".2s"><a href="https://plus.google.com/116467119361947341192/posts"><i class="fa fa-google-plus"></i></a></li>
                        <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".3s"><a href="#"><i class="fa fa-dribbble"></i></a></li>
                        <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".4s"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".5s"><a href="https://twitter.com/talagasoft"><i class="fa fa-twitter"></i></a></li>
                        <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".6s"><a href="#"><i class="fa fa-skype"></i></a></li>
                        <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".7s"><a href="#"><i class="fa fa-github"></i></a></li>
                        <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".8s"><a href="#"><i class="fa fa-youtube"></i></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                  <div class="copyright">
                    <p>&copy; 2015 - Copyright - Talagasoft Indonesia.</p>
                  </div>
                </div>
            </div>
        </div>
    </footer>
    <!--small footer end-->
