<div class='thumbnail box-gradient'>
<?=link_button("Help","load_help()","help")?>
</div>
<legend>PROSES VERIFIKASI</legend>
<p>Dibawah ini adalah daftar aplikasi permohonan kredit yang belum diverifikasi
silahkan klik nomor tersebut untuk diverifikasi</p>
<?=$not_verified?>
<p>&nbsp</p>
<div class='' id='divResult' style="display:none">
	<legend>STEP 1 - Info Aplikasi Kredit </legend>
	<p>Dibawah ini adalah data-data yang perlu anda verifikasi sebagai berikut: Tekan tombol <strong>Proses</strong> untuk mulai verifikasi </p>
	<div id='divResultContent'>
	
	</div>
	<p>&nbsp</p>
	<div class='thumbnail'>
	<button type="button" onclick="on_step1()" class="btn btn-info">PROSES</button>
	</div>
</div>

<p>&nbsp</p>
<div id='dlgVerifyData'class="easyui-dialog" style="width:600px;height:400px;padding:10px 20px" closed="true" 
	buttons="#tbVerifyData">
	<? include_once "verify_form.php" ?>
</div>
<div id='tbVerifyData'>
	<button type="button" onclick="save()" class="btn btn-info">SIMPAN</button>
</div>

<script language="javascript">
	var m_app_id="";
	function step1(app_id){
		m_app_id=app_id;
		var url="<?=base_url()?>index.php/leasing/verify/step1/"+app_id;
		get_this(url,"","divResultContent");
		$("#divResult").fadeIn('slow');
		$("#divResultStep1").fadeOut('slow');
	}
	function on_step1(){
		$("#dlgVerifyData").dialog("open").dialog('setTitle','Isi data verifikasi');;
	}
  	function save(){
  		if(m_app_id==''){alert('Isi kode aplikasi !');return false;}
		if(!confirm('Data sudah benar ? Yakin mau disimpan ?')) return false;
		url='<?=base_url()?>index.php/leasing/verify/save/';
		$("#dlgVerifyData").dialog("close");
		$("#app_id").val(m_app_id);
		$('#frmMain').form('submit',{
			url: url, onSubmit: function(){	return $(this).form('validate'); },
			success: function(result){
				var result = eval('('+result+')');
				if (result.success){
					url="<?=base_url()?>index.php/leasing/verify";
					log_msg('Data sudah tersimpan.');
					window.open(url,"_self");
				} else {
					log_err(result.msg);
				}
			}
		});
  	}
	 
	function load_help() {
		window.parent.$("#help").load("<?=base_url()?>index.php/help/load/app_verify");
	}
	
</script>