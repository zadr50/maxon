
    <div class="col-sm-6 col-md-4"><h2>Reports</h2>
 		<div class="thumbnail">
			<p><?=anchor('banks/rpt/mutasi','Mutasi Transaksi Rekening')?></p>
 		</div>
    </div>