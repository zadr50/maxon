<button id="btn_up" class="input-button nav-button" >Up</button>
<button id="btn_dn" class="input-button nav-button" >Down</button>
<br>					
<button class="input-button number-char">1</button>
<button class="input-button number-char">2</button>
<button class="input-button number-char">3</button>
<button id="btn_qty" class="mode-button selected-mode" data-mode="quantity">Qty</button>
<br>
<button class="input-button number-char">4</button>
<button class="input-button number-char">5</button>
<button class="input-button number-char">6</button>
<button id="btn_disc"  class="mode-button" data-mode="discount">Disc</button>
<br>
<button class="input-button number-char">7</button>
<button class="input-button number-char">8</button>
<button class="input-button number-char">9</button>
<button id="btn_price" class="mode-button" data-mode="price">Price</button>
<br>
<button class="input-button numpad-minus">+/-</button>
<button class="input-button number-char">0</button>
<button class="input-button number-char">.</button>
<button class="input-button numpad-backspace"><-</button>
<br>
<button class="input-button number-char">00</button>
<button class="input-button number-char">000</button>
<button class="input-button number-char">.</button>
<button id="btn_pay" class="mode-button" data-mode="pay">Pay</button>
<br>