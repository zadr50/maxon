    <!--header start-->
    <header class="head-section">
      <div class="navbar navbar-default navbar-static-top container">
          <div class="navbar-header">
              <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse" type="button">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="<?=base_url()?>">
			  <img src='<?=base_url("images/logo_maxon.png")?>' style="width:100px;height:50px">
			  </a>
          </div>
          <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
              	<p>
      			  <?=anchor('sekolah/login',"Login","class='btn btn-primary' style='margin-top:10px'")?>              		
              	</p>
              </ul>
          </div>
      </div>
    </header>
    <!--header end-->
