<div class="easyui-tabs" id="tt">	 
	<div title="HOME" style="padding:10px; min-height:650px">
		<?php	
		    $home="home.php";
			include_once $home; 
		?>
   </div>
</div>
<div class="clearfix"></div>
